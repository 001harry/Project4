// Assuming items.json is a JSON file with an array of food items
// Each food item is an object with properties: name, price

// Fetch all items from items.json
let items = [];
fetch('items.json')
    .then(response => response.json())
    .then(data => items = data)
    .catch(error => console.error('Error:', error));

// Get references to the form and results section
const form = document.getElementById('search-form');
const resultsSection = document.getElementById('search-results');

// Add event listener to the form
form.addEventListener('submit', function(event) {
    // Prevent the form from submitting normally
    event.preventDefault();

    // Clear previous results
    resultsSection.innerHTML = '';

    // Get the search term
    const searchTerm = document.getElementById('search-input').value;

    // Filter items based on the search term
    const filteredItems = items.filter(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()));

    // Display the filtered items
    filteredItems.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.innerHTML = `
            <h3>${item.name}</h3>
            <p>Price: ${item.price}</p>
            <a href="items.html?name=${encodeURIComponent(item.name)}">View Details</a>
        `;
        resultsSection.appendChild(itemElement);
    });
});
