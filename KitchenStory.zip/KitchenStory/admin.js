// Assuming items.json is a JSON file with an array of food items
// Each food item is an object with properties: name, price

let items = [];
fetch('items.json')
    .then(response => response.json())
    .then(data => items = data)
    .catch(error => console.error('Error:', error));

const adminLoginForm = document.getElementById('admin-login-form');
const adminPasswordInput = document.getElementById('admin-password');
const adminDashboard = document.getElementById('admin-dashboard');
const addItemForm = document.getElementById('add-item-form');
const itemNameInput = document.getElementById('item-name');
const itemPriceInput = document.getElementById('item-price');
const itemsList = document.getElementById('items-list');

// Admin password for demonstration purposes
const adminPassword = 'admin';

adminLoginForm.addEventListener('submit', function(event) {
    event.preventDefault();

    if (adminPasswordInput.value === adminPassword) {
        adminLoginForm.style.display = 'none';
        adminDashboard.style.display = 'block';
    } else {
        alert('Incorrect password');
    }
});

addItemForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const newItem = {
        name: itemNameInput.value,
        price: itemPriceInput.value
    };

    items.push(newItem);

    // Update items.json file
    // This would require server-side code in a real application
    // For this demonstration, we'll just log the updated items array
    console.log('Updated items:', items);

    // Clear the input fields
    itemNameInput.value = '';
    itemPriceInput.value = '';

    // Update the items list
    updateItemsList();
});

function updateItemsList() {
    itemsList.innerHTML = '';

    items.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.innerHTML = `
            <p>Name: ${item.name}</p>
            <p>Price: ${item.price}</p>
            <button onclick="removeItem('${item.name}')">Remove Item</button>
        `;

        itemsList.appendChild(itemElement);
    });
}

function removeItem(itemName) {
    items = items.filter(item => item.name !== itemName);

    // Update items.json file
    // This would require server-side code in a real application
    // For this demonstration, we'll just log the updated items array
    console.log('Updated items:', items);

    // Update the items list
    updateItemsList();
}

// Initial update of the items list
updateItemsList();
