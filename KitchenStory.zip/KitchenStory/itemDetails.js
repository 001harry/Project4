// Assuming items.json is a JSON file with an array of food items
// Each food item is an object with properties: name, price

// Fetch all items from items.json
let items = [];
fetch('items.json')
    .then(response => response.json())
    .then(data => items = data)
    .catch(error => console.error('Error:', error));

// Get the item name from the URL
const urlParams = new URLSearchParams(window.location.search);
const itemName = decodeURIComponent(urlParams.get('name'));

// Find the item in the items array
const item = items.find(item => item.name === itemName);

// If the item was found, display its details
if (item) {
    const itemDetailsSection = document.getElementById('item-details');
    itemDetailsSection.innerHTML = `
        <h2>${item.name}</h2>
        <p>Price: ${item.price}</p>
    `;

    // Add event listener to the purchase button
    const purchaseButton = document.getElementById('purchase-button');
    purchaseButton.addEventListener('click', function() {
        // Redirect to the checkout page with the item name in the URL
        window.location.href = `checkout.html?name=${encodeURIComponent(item.name)}`;
    });
} else {
    // If the item was not found, display an error message
    const itemDetailsSection = document.getElementById('item-details');
    itemDetailsSection.innerHTML = `
        <p>Item not found.</p>
    `;
}
