// Assuming items.json is a JSON file with an array of food items
// Each food item is an object with properties: name, price

// Fetch all items from items.json
let items = [];
fetch('items.json')
    .then(response => response.json())
    .then(data => items = data)
    .catch(error => console.error('Error:', error));

// Get the item name from the URL
const urlParams = new URLSearchParams(window.location.search);
const itemName = decodeURIComponent(urlParams.get('name'));

// Find the item in the items array
const item = items.find(item => item.name === itemName);

// If the item was found, display its details in the checkout section
if (item) {
    const checkoutDetailsSection = document.getElementById('checkout-details');
    checkoutDetailsSection.innerHTML = `
        <h2>${item.name}</h2>
        <p>Price: ${item.price}</p>
    `;
} else {
    // If the item was not found, display an error message
    const checkoutDetailsSection = document.getElementById('checkout-details');
    checkoutDetailsSection.innerHTML = `
        <p>Item not found.</p>
    `;
}

// Handle form submission
const paymentForm = document.getElementById('payment-form');
paymentForm.addEventListener('submit', function(event) {
    // Prevent the form from being submitted normally
    event.preventDefault();

    // Get the form values
    const cardNumber = document.getElementById('card-number').value;
    const expiryDate = document.getElementById('expiry-date').value;
    const cvv = document.getElementById('cvv').value;

    // Validate the form values
    if (!cardNumber || !expiryDate || !cvv) {
        alert('Please fill in all fields.');
        return;
    }

    // If the form values are valid, redirect to the confirmation page with the item name in the URL
    window.location.href = `confirmation.html?name=${encodeURIComponent(item.name)}`;
});
